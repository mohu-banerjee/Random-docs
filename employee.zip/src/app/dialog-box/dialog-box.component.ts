import { Component, OnInit } from '@angular/core';
import { MatDialogRef  } from '@angular/material/dialog';
import employee from '../employee.json';
interface Employees {
  id: Number;
  sapId: Number;
  name: String;
  email: String;
  gender: String;
  contact: Number;
  rm: string;
}
@Component({
  selector: 'app-dialog-box',
  templateUrl: './dialog-box.component.html',
  styleUrls: ['./dialog-box.component.css']
})
export class DialogBoxComponent implements OnInit {
  
  employeeData: Employees[] = employee;
  constructor(public dialogRef: MatDialogRef<DialogBoxComponent>) { }

  ngOnInit(): void {
  }


  onSubmit(){
    
  }
  closeDialog(){
    this.dialogRef.close({event:'Cancel'});
  }
}
