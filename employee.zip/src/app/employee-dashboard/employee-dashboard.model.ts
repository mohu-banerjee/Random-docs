export class EmployeeModel{
    id : number = 0;
    sapID : string = '';
    
    firstName : string = '';
    email : string = '';
    gender : string = '';
    contact : number = 0;
    rm : string = '';
}