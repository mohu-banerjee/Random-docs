import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms'

//import employee from '../employee.json';
//import { MatDialog } from '@angular/material/dialog';
import { EmployeeModel } from './employee-dashboard.model';
import { ApiService } from '../shared/api.service';

// interface Employees {
//   id: Number;
//   sapId: Number;
//   name: String;
//   email: String;
//   gender: String;
//   contact: Number;
//   rm: string;
// }
@Component({
  selector: 'app-employee-dashboard',
  templateUrl: './employee-dashboard.component.html',
  styleUrls: ['./employee-dashboard.component.scss']
})
export class EmployeeDashboardComponent implements OnInit {

  formValue !: FormGroup;
  //employeeData: Employees[] = employee;
  employeeModelObj : EmployeeModel = new EmployeeModel();
  employeeData !: any;
  showAdd!: boolean;
  showUpdate !: boolean;
  constructor(private formbuilder: FormBuilder, private api : ApiService) {}


  ngOnInit(): void {
    this.formValue = this.formbuilder.group({
      sapID : [''],
      firstName : [''],
      email : [''],
      gender : [''],
      contact : [''],
      rm : [''],
    })
    this.getAllEmployee();
  }
  clickAddEmploye(){
    this.formValue.reset();
    this.showAdd = true;
    this.showUpdate = false;
  }
  postEmplyeeDetails(){
    this.employeeModelObj.sapID = this.formValue.value.sapID;
    this.employeeModelObj.firstName = this.formValue.value.firstName;
    this.employeeModelObj.email = this.formValue.value.email;
    this.employeeModelObj.gender = this.formValue.value.gender;
    this.employeeModelObj.contact = this.formValue.value.contact;
    this.employeeModelObj.rm = this.formValue.value.rm;

    this.api.postEmployee(this.employeeModelObj)
    .subscribe(res=>{
      console.log(res);
      alert("Employee Added Successfully"); 
      let ref = document.getElementById('cancel')
      ref?.click();
      this.formValue.reset();
      this.getAllEmployee();
    },
    err=>{
      alert("somthing went Wrong");
    }
    )
  }

  getAllEmployee(){
    this.api.getEmployee()
    .subscribe((res: any)=>{
      this.employeeData = res;
    })
  }

  deleteEmploye(row : any){
    this.api.deleteEmployee(row.id)
    .subscribe(res=>{
      alert("Employee Deleted");
      this.getAllEmployee();
    })
  }

  onEdit(row: any){
    this.showAdd = false;
    this.showUpdate = true;
    this.employeeModelObj.id = row.id;
    this.formValue.controls['sapID'].setValue(row.sapID);
    this.formValue.controls['firstName'].setValue(row.firstName);
    this.formValue.controls['email'].setValue(row.email);
    this.formValue.controls['gender'].setValue(row.gender);
    this.formValue.controls['contact'].setValue(row.contact);
    this.formValue.controls['rm'].setValue(row.rm);
  }
  updateEmplyeeDetails(){
    this.employeeModelObj.sapID = this.formValue.value.sapID;
    this.employeeModelObj.firstName = this.formValue.value.firstName;
    this.employeeModelObj.email = this.formValue.value.email;
    this.employeeModelObj.gender = this.formValue.value.gender;
    this.employeeModelObj.contact = this.formValue.value.contact;
    this.employeeModelObj.rm = this.formValue.value.rm;

    this.api.updateEmployee(this.employeeModelObj, this.employeeModelObj.id)
    .subscribe(res=>{
      alert("Updated successfully");
      let ref = document.getElementById('cancel')
      ref?.click();
      this.formValue.reset();
      this.getAllEmployee();
    })
  }
}
